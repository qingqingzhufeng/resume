// pages/search/search.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    lists:[],              // 接收搜索的内容
    searchValue: '',       // 输入的值
    daindex1:1,
    daindex2:2,
    daindex3:3,
    cur1:0,
    cur2:0,
    cur3:0
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    if (options.value.length > 0) {
      this.search(options.value);
    }
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },
  suo: function (e) {
    this.search(this.data.searchValue);
    // console.log(this.data.searchValue)
  },
  //获取用户输入搜索的文字
  wxSearchInput(e) {
    // console.log(e.detail.value)
    this.setData({
      searchValue: e.detail.value
    })
  },
  //封装的搜索事件  调用时参数
  search:function(val){
    this.setData({
      cur1:1,
      cur2:0,
      cur3:0
    })
    wx.request({
      url: 'http://127.0.0.1:5000/search/search',
      data: {
        value: val
      },
      header: { 'content-type': 'application/x-www-form-urlencoded' },
      method: "POST",
      success: (res) => {
        var list = []
        if (res.data.code == 200) {
          console.log(res.data.msg);
          list = res.data.msg
        };
        this.setData({
          lists: list,
          searchValue: val,
          cur1:1
        })
      }
    })
  },
  //点击排序事件
  news:function(e){
    var cur2 = this.data.cur2;
    var ls = this.data.lists;
    var l = [];
    if (e.currentTarget.dataset.index == 1){
      this.search(this.data.searchValue);
      this.setData({
        cur1: 1,
        cur2: 0,
        cur3: 0,
      })
    }else if(e.currentTarget.dataset.index == 2) {
      if(cur2 == 0){
        for (var i = 0; i < ls.length - 1; i++) {
          for (var j = i + 1; j < ls.length; j++) {
            if (ls[i].price >= ls[j].price) {
              l = ls[i];
              ls[i] = ls[j];
              ls[j] = l;
            }
          }
        }
        this.setData({
          cur1: 0,
          cur2: 1,
          cur3: 0,
          lists: ls
        })
      }else if (cur2 == 1) {
        for (var i = 0; i < ls.length - 1; i++) {
          for (var j = i+1; j < ls.length; j++) {
            if (ls[i].price < ls[j].price) {
              l = ls[i];
              ls[i] = ls[j];
              ls[j] = l;
            } else if (ls[i].price == ls[j].price) {
              continue;
            }
          }
        }
        console.log(ls);
        this.setData({
          cur1: 0,
          cur2: 2,
          cur3: 0,
          lists: ls
        })
      }else {
        for (var i = 0; i < ls.length - 1; i++) {
          for (var j = i + 1; j < ls.length; j++) {
            if (ls[i].price > ls[j].price) {
              l = ls[i];
              ls[i] = ls[j];
              ls[j] = l;
            } else if (ls[i].price == ls[j].price) {
              continue;
            }
          }
        }
        this.setData({
          cur1: 0,
          cur2: 1,
          cur3: 0,
          lists: ls
        })
      }
    }else if(e.currentTarget.dataset.index == 3) {
      this.setData({
        cur1: 0,
        cur2: 0,
        cur3: 1,
      })
    }
  }, 
})
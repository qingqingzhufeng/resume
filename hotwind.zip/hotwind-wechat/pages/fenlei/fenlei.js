// pages/fenlei/fenlei.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    fenleilist:[],
    fimg:'',
    imglist:[],
    selectId:10,
    fid:10,
  },
  select:function(e){
    var fid = e.currentTarget.dataset.id;
    wx.request({
      url: "http://127.0.0.1:5000/product/fenleiimg?fid=" + fid,
      success: (res) => {
        this.setData({
          imglist: res.data.msg
        });
      }

      
    })
    var fimg = '';
    for(var item of this.data.fenleilist){
      if(item.fid == fid){
        fimg = item.fimg;
      }
    }
    this.setData({
      selectId:fid,
      fimg: fimg
    }) 
  },
  // showScroll:function(e){
  //   console.log(e)
  //   console.log(6666);
  // },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    wx.request({
      url: "http://127.0.0.1:5000/product/fenlei",
      success: (res) => {
        this.setData({
          fenleilist: res.data.msg,
          fimg:res.data.msg[0].fimg
        });
        console.log(res.data.msg);
      }
    });
    var fid = this.data.fid;
    console.log(fid);
    wx.request({
      url: "http://127.0.0.1:5000/product/fenleiimg?fid="+fid,
      success: (res) => {
        this.setData({
          imglist: res.data.msg
        });     
      }
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})
//mini/pages/logs/logs.js
Page({

  /**
   * 页面的初始数据
  */
  data: {
    imagelist:[],
    bottom:[],
    prdList:{},
    searchValue: '',       // 输入的值
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    if(wx.getStorageSync('user')){
      console.log(wx.getStorageSync('user'));
    }else{
      wx.login({
        success(res) {
          if (res.code) {
            //发起网络请求
            wx.request({
              url: 'http://127.0.0.1:5000/user/getCode?code=' + res.code,
              success: (res) => {
                var user = {};
                user.info = res.data;
                user.orderList = [];
                wx.setStorage({
                  key: 'user',
                  data: user,
                })
              }
            })
          } else {
            console.log('登录失败！' + res.errMsg)
          }
        }
      })
    }
    
      wx.request({
        url:"http://127.0.0.1:5000/swipe/lun",
        success:(res)=>{
          var d = [];
          var b = [];
          var s =  res.data.msg;
          for(var i of s){
            if(i.isLun == 1){
              d.push(i);
            }if(i.isLun == 2){
              b.push(i)
            }
          }
          this.setData({
           imagelist:d,
           bottom:b
          });
        }
      });
      wx.request({
        url: 'http://127.0.0.1:5000/product/all',
        success:(res)=>{
          var s = res.data.msg;
          this.setData({
            prdList:s
          });
        } 
      })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
    
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
    console.log("5:监听用户下拉动作");
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    console.log("6:监听用户上拉动作");
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
    
  },
  suo: function (e) {
    wx.navigateTo({
      url: '../search/search?value=' + this.data.searchValue
    })
  },                                                                         //获取用户输入搜索的文字
  wxSearchInput(e) {
    // console.log(e.detail.value)
    this.setData({
      searchValue: e.detail.value
    })
  },                                                              
})
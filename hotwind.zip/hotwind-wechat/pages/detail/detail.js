// pages/detail/detail.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    searchValue:'',  //input输入内容
    detailImage:[ //轮播图片
      '/assets/images/detail1.jpg',
      '/assets/images/detail2.jpg',
      '/assets/images/detail3.jpg',
      '/assets/images/detail4.jpg',
      '/assets/images/detail5.jpg',
    ],
    jieshao:[],//商品介绍
    product:{},//商品详情
    isShow :false,//是否显示规格选择
    nums:1,//商品数量
    types:0,//提交方式（到购物车还是立即购买，0为购物车，1为立即购买）
    color:'',//颜色规格
    size:'',//尺寸规格
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    
    var id = options.id;
    wx.request({
      url: 'http://127.0.0.1:5000/product/product?id='+id,
      success:(res)=>{
        res.data.msg[0].size = res.data.msg[0].size.split(',');
        res.data.msg[0].color = res.data.msg[0].color.split(',');
        
        this.setData({
          product:res.data.msg[0]
        })
      }
    })
    wx.request({
        url: 'http://127.0.0.1:5000/product/proImg',
        success: (res) => {
          this.setData({
            jieshao: res.data.msg
          })
        }
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },
  // 头部搜索
  suo: function (e) {
    wx.navigateTo({
      url: '../search/search?value=' + this.data.searchValue
    })
  },
  //获取用户输入搜索的文字
  wxSearchInput(e) {
    // console.log(e.detail.value)
    this.setData({
      searchValue: e.detail.value
    })
  },
  detail: function (e) {
  },
  // 打开规格选择
  showSelect:function(e){
    var types = e.currentTarget.dataset.type;
    this.setData({
      isShow:true,
      types:types
    })
  },
  // 关闭规格选择
  closeSelect(){
    this.setData({
      isShow: false
    })
  },
  // 跳转到首页
  goIndex(){
    wx.switchTab({
      url: '../index/index',
    })
  },
  // 跳转到分类页
  goFenlei(){
    wx.switchTab({
      url: '../fenlei/fenlei',
    })
  },
  // 获取颜色规格
  getColor(e){
    var color =e.currentTarget.dataset.color;
    this.setData({
      color:color
    })
  },
  // 获取尺寸规格
  getSize(e){
    var size = e.currentTarget.dataset.size;
    this.setData({
      size:size
    })
  },
  // 获取购买数量
  getNums(e){
    var nums = e.detail.value;
    var reg = /^[0-9]+?[0-9]*$/
    if(reg.test(nums)){
      if (nums < 1) {
        nums = 1;
      } else if (nums > 99) {
        nums = 99;
      }
    }else{
      nums = 1;
    }
    this.setData({
      nums:nums
    })
  },
  // 点击修改数量
  btnClick(e){
    var btn = Number(e.target.dataset.btn);
    var nums = this.data.nums;
    if(nums <=1){
      if(btn==-1){
        return;
      }
    }
    if(nums>=99){
      if (btn == 1) {
        return;
      }
    }
    nums = nums+btn;
    this.setData({
      nums:nums
    })
  },
  // 提交到购物车或者立即购买
  submit(){
    var order = {};
    var isYiyou = false;
    var user = wx.getStorageSync('user');
    order.types = this.data.types;
    order.color = this.data.color;
    order.size = this.data.size;
    order.pro = this.data.product;
    order.num = this.data.nums;
    order.userID = user.info.openid;
    for(var item of user.orderList){
      if(order.pro.pid == item.pro.pid && order.color == item.color && order.size == item.size){
        item.num += order.num;
        isYiyou = true;
      }
    }
    if(!isYiyou){
      user.orderList.push(order);
    }
    wx.setStorage({
      key: 'user',
      data: user,
    })
    if(this.data.color&&this.data.size){
      if (this.data.types == 0) {
        wx.switchTab({
          url: '../car/car',
        })
      } else if (this.data.types == 1) {
        wx.switchTab({
          url: '../index/index',
        })
      }
    }
  }
})
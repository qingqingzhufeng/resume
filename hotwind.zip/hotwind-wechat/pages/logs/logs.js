//mini/pages/logs/logs.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
     imagelist:[],
     product1:[]
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
      wx.request({
        url:"http://127.0.0.1:5000/swipe/lun",
        success:(res)=>{
          var d = [];
          var s =  res.data.msg;
          for(var i of s){
            if(i.isLun ==1){
              d.push(i);
            }
          }
          this.setData({
           imagelist:d
          });
        }
      });
      wx.request({
        url: 'http://127.0.0.1:5000/product/all',
        success:(res)=>{
          console.log(res.data.msg);
          var s = res.data.msg;
          var d = [];
          var a = 0;
          for(var i of s){
            if (i.head == "recommended"){   
           
              i.price = i.price.toFixed(2);
              i.oldPrice = i.oldPrice.toFixed(2); 
              d.push(i);
              // console.log(m);
            }
          }
          this.setData({
            product1: d
          });
        }
      })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    console.log("2:onReady");
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    console.log("3:onShow")
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
    console.log("4:onHide")
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
    
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
    console.log("5:监听用户下拉动作");
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    console.log("6:监听用户上拉动作");
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
    
  }
})
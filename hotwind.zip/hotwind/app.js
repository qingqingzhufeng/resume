//加载模块 express
const express = require("express");
const bodyParser = require("body-parser");

var product = require('./router/product');
var swipe = require("./router/swipe");
var search = require("./router/search");
var user = require("./router/user");
//创建服务器
var app = express();
app.listen(5000,()=>{
    console.log("服务器已启动");
});

//挂载静态资源
app.use(express.static('./public'));
app.use(bodyParser.urlencoded({
    extended: false
}));

// 挂载路由器
app.use('/product',product);
app.use('/swipe',swipe);
app.use('/search',search);
app.use('/user',user);
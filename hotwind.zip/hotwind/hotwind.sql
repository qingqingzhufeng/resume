SET NAMES UTF8;
--查找是否存在该数据库，存在即删除
DROP DATABASE IF EXISTS hotwind;
--创建Hotwind数据库
CREATE DATABASE hotwind CHARSET=utf8;
--进入 数据库hotwind
USE hotwind;
--创建product数据表
CREATE TABLE product(
    id INT PRIMARY KEY AUTO_INCREMENT,
    head VARCHAR(16),      #头部标题
    title VARCHAR(128),    #标题
    pic VARCHAR(128),      #图片
    price DECIMAL(6,2),    #价格
    oldPrice DECIMAL(6,2),  #原始价格
    color VARCHAR(128),    #产品颜色
    size VARCHAR(128)      #产品尺寸
);
-- 创建订单表
CREATE TABLE myorder(
    id INT PRIMARY KEY AUTO_INCREMENT,
    pid INT,
    num INT,
    color VARCHAR(32),
    size INT, 
    userId VARCHAR(128)
);

#本周尖货推荐
INSERT INTO product VALUES(NULL,"recommended","热风新款一脚套女士休闲靴H82W8810","http://127.0.0.1:5000/home/bzjhtj/bz1.jpg",169.00,229.00,"01黑色,08杏色","34,35,36,37,38,39,40");
INSERT INTO product VALUES(NULL,"recommended","热风新款一脚套女士休闲靴H82W8810","http://127.0.0.1:5000/home/bzjhtj/bz2.jpg",99.00,149.00,"01黑色","37,38,39,40,41,42,43,44,45");
INSERT INTO product VALUES(NULL,"recommended","热风新款一脚套女士休闲靴H82W8810","http://127.0.0.1:5000/home/bzjhtj/bz3.jpg",189.00,249.00,"01黑色","38,39,40,41,42,43,44");
INSERT INTO product VALUES(NULL,"recommended","热风新款一脚套女士休闲靴H82W8810","http://127.0.0.1:5000/home/bzjhtj/bz4.jpg",169.00,269.00,"01黑色,09灰色","34,35,39,37,38,39,40");
INSERT INTO product VALUES(NULL,"recommended","热风新款一脚套女士休闲靴H82W8810","http://127.0.0.1:5000/home/bzjhtj/bz5.jpg",169.00,199.00,"08杏色","34,35,39,37,38,39,40");
INSERT INTO product VALUES(NULL,"recommended","热风新款一脚套女士休闲靴H82W8810","http://127.0.0.1:5000/home/bzjhtj/bz6.jpg",129.00,149.00,"01黑色","34,35,39,37,38,39,40");

#活动导航
INSERT INTO product VALUES(NULL,"hddh",NULL,"http://127.0.0.1:5000/home/hddh/hddh1.jpg",NULL,NULL,NULL,NULL);
INSERT INTO product VALUES(NULL,"hddh",NULL,"http://127.0.0.1:5000/home/hddh/hddh2.jpg",NULL,NULL,NULL,NULL);
INSERT INTO product VALUES(NULL,"hddh",NULL,"http://127.0.0.1:5000/home/hddh/hddh3.jpg",NULL,NULL,NULL,NULL);
INSERT INTO product VALUES(NULL,"hddh",NULL,"http://127.0.0.1:5000/home/hddh/hddh4.jpg",NULL,NULL,NULL,NULL);
INSERT INTO product VALUES(NULL,"hddh",NULL,"http://127.0.0.1:5000/home/hddh/hddh5.jpg",NULL,NULL,NULL,NULL);
INSERT INTO product VALUES(NULL,"hddh",NULL,"http://127.0.0.1:5000/home/hddh/hddh6.jpg",NULL,NULL,NULL,NULL);
INSERT INTO product VALUES(NULL,"hddh",NULL,"http://127.0.0.1:5000/home/hddh/hddh7.jpg",NULL,NULL,NULL,NULL);
INSERT INTO product VALUES(NULL,"hddh",NULL,"http://127.0.0.1:5000/home/hddh/hddh8.jpg",NULL,NULL,NULL,NULL);
INSERT INTO product VALUES(NULL,"hddh",NULL,"http://127.0.0.1:5000/home/hddh/hddh9.jpg",NULL,NULL,NULL,NULL);
INSERT INTO product VALUES(NULL,"hddh",NULL,"http://127.0.0.1:5000/home/hddh/hddh10.jpg",NULL,NULL,NULL,NULL);

#靓丽女鞋
INSERT INTO product VALUES(NULL,"nvx",NULL,"http://127.0.0.1:5000/home/llnx/nvx4.jpg",NULL,NULL,NULL,NULL);
INSERT INTO product VALUES(NULL,"nvx",NULL,"http://127.0.0.1:5000/home/llnx/nvx2.jpg",NULL,NULL,NULL,NULL);
INSERT INTO product VALUES(NULL,"nvx",NULL,"http://127.0.0.1:5000/home/llnx/nvx1.jpg",NULL,NULL,NULL,NULL);
INSERT INTO product VALUES(NULL,"nvx",NULL,"http://127.0.0.1:5000/home/llnx/nvx3.jpg",NULL,NULL,NULL,NULL);
INSERT INTO product VALUES(NULL,"llnx","热风2017年女士一脚套休闲鞋H14W7707","http://127.0.0.1:5000/home/llnx/llnx1.jpg",59.00,169.00,"01黑色","34,35,39,37,38,39,40");
INSERT INTO product VALUES(NULL,"llnx","热风时尚系带休闲鞋H12W8703","http://127.0.0.1:5000/home/llnx/llnx2.jpg",199.00,299.00,"01黑色","34,35,39,37,38,39,40");
INSERT INTO product VALUES(NULL,"llnx","热风新款女士时尚休闲靴H82W8813","http://127.0.0.1:5000/home/llnx/llnx3.jpg",299.00,349.00,"01黑色","34,35,39,37,38,39,40");
INSERT INTO product VALUES(NULL,"llnx","热风新款女士时尚工装皮鞋H20W8807","http://127.0.0.1:5000/home/llnx/llnx4.jpg",409.00,499.00,"01黑色","34,35,39,37,38,39,40");

#舒适男鞋
INSERT INTO product VALUES(NULL,"nanx",NULL,"http://127.0.0.1:5000/home/ssnx/nb1.jpg",NULL,NULL,NULL,NULL);
INSERT INTO product VALUES(NULL,"nanx",NULL,"http://127.0.0.1:5000/home/ssnx/nb2.jpg",NULL,NULL,NULL,NULL);
INSERT INTO product VALUES(NULL,"nanx",NULL,"http://127.0.0.1:5000/home/ssnx/nb3.jpg",NULL,NULL,NULL,NULL);
INSERT INTO product VALUES(NULL,"nanx",NULL,"http://127.0.0.1:5000/home/ssnx/nb4.jpg",NULL,NULL,NULL,NULL);
INSERT INTO product VALUES(NULL,"ssnx","热风秋季新款男士橡筋硫化鞋H14M8309","http://127.0.0.1:5000/home/ssnx/ssnx1.jpg",59.00,169.00,"01黑色","34,35,39,37,38,39,40");
INSERT INTO product VALUES(NULL,"ssnx","热风秋季新款男士休闲皮鞋H20M8706","http://127.0.0.1:5000/home/ssnx/ssnx2.jpg",199.00,299.00,"01黑色","34,35,39,37,38,39,40");
INSERT INTO product VALUES(NULL,"ssnx","热风男士休闲皮鞋H43M8703","http://127.0.0.1:5000/home/ssnx/ssnx3.jpg",299.00,349.00,"01黑色","34,35,39,37,38,39,40");
INSERT INTO product VALUES(NULL,"ssnx","热风新款男士时尚硫化鞋H92M8806","http://127.0.0.1:5000/home/ssnx/ssnx4.jpg",409.00,499.00,"01黑色","34,35,39,37,38,39,40");

#时尚女包
INSERT INTO product VALUES(NULL,"nvb",NULL,"http://127.0.0.1:5000/home/ssnb/nb1.jpg",NULL,NULL,NULL,NULL);
INSERT INTO product VALUES(NULL,"nvb",NULL,"http://127.0.0.1:5000/home/ssnb/nb2.jpg",NULL,NULL,NULL,NULL);
INSERT INTO product VALUES(NULL,"nvb",NULL,"http://127.0.0.1:5000/home/ssnb/nb3.jpg",NULL,NULL,NULL,NULL);
INSERT INTO product VALUES(NULL,"nvb",NULL,"http://127.0.0.1:5000/home/ssnb/nb4.jpg",NULL,NULL,NULL,NULL);
INSERT INTO product VALUES(NULL,"ssnb","热风新款女士粗呢链条包B57W8802","http://127.0.0.1:5000/home/ssnb/ssnb1.jpg",169.00,199.00,"01黑色","34,35,39,37,38,39,40");
INSERT INTO product VALUES(NULL,"ssnb","热风新款女士格子双肩包B52W8803","http://127.0.0.1:5000/home/ssnb/ssnb2.jpg",169.00,199.00,"01黑色","34,35,39,37,38,39,40");
INSERT INTO product VALUES(NULL,"ssnb","热风新款女士时尚手提包B59W8303","http://127.0.0.1:5000/home/ssnb/ssnb3.jpg",299.00,NULL,"01黑色","34,35,39,37,38,39,40");

#精品男包
INSERT INTO product VALUES(NULL,"nanb",NULL,"http://127.0.0.1:5000/home/jpnb/nb1.jpg",NULL,NULL,NULL,NULL);
INSERT INTO product VALUES(NULL,"nanb",NULL,"http://127.0.0.1:5000/home/jpnb/nb2.jpg",NULL,NULL,NULL,NULL);
INSERT INTO product VALUES(NULL,"nanb",NULL,"http://127.0.0.1:5000/home/jpnb/nb3.jpg",NULL,NULL,NULL,NULL);
INSERT INTO product VALUES(NULL,"nanb",NULL,"http://127.0.0.1:5000/home/jpnb/nb4.jpg",NULL,NULL,NULL,NULL);
INSERT INTO product VALUES(NULL,"jpnb","热风迷彩胸包B55M8703","http://127.0.0.1:5000/home/jpnb/jpnb1.jpg",139.00,169.00,"01黑色","34,35,39,37,38,39,40");
INSERT INTO product VALUES(NULL,"jpnb","热风休闲斜挎包B57M8703","http://127.0.0.1:5000/home/jpnb/jpnb2.jpg",199.00,269.00,"01黑色","34,35,39,37,38,39,40");
INSERT INTO product VALUES(NULL,"jpnb","热风简约手提包B51M8701","http://127.0.0.1:5000/home/jpnb/jpnb3.jpg",249.00,329.00,"01黑色","34,35,39,37,38,39,40");
INSERT INTO product VALUES(NULL,"jpnb","热风学院双肩包B52M8701","http://127.0.0.1:5000/home/jpnb/jpnb4.jpg",249.00,329.00,"01黑色","34,35,39,37,38,39,40");

#男女服饰专区
INSERT INTO product VALUES(NULL,"nannv",NULL,"http://127.0.0.1:5000/home/nvfszq/nvfs1.jpg",NULL,NULL,NULL,NULL);
INSERT INTO product VALUES(NULL,"nannv",NULL,"http://127.0.0.1:5000/home/nvfszq/nvfs2.jpg",NULL,NULL,NULL,NULL);
INSERT INTO product VALUES(NULL,"nvfszq","Hotwind新款女士荷叶边衬衣F02W8302","http://127.0.0.1:5000/home/nvfszq/nvfszq1.jpg",199.00,NULL,"01黑色","34,35,39,37,38,39,40");
INSERT INTO product VALUES(NULL,"nvfszq","Hotwind新款女士中长款经典风衣F07W8306","http://127.0.0.1:5000/home/nvfszq/nvfszq2.jpg",469.00,NULL,"01黑色","34,35,39,37,38,39,40");
INSERT INTO product VALUES(NULL,"nvfszq","Hotwind新款女士破洞牛仔外套F07W8304","http://127.0.0.1:5000/home/nvfszq/nvfszq3.jpg",369.00,NULL,"01黑色","34,35,39,37,38,39,40");
INSERT INTO product VALUES(NULL,"nvfszq","Hotwind新款男士时尚连帽夹克F07M8308","http://127.0.0.1:5000/home/nvfszq/nvfszq4.jpg",469.00,NULL,"01黑色","34,35,39,37,38,39,40");

##积分商城
INSERT INTO product VALUES(NULL,"jfsc",NULL,"http://127.0.0.1:5000/home/jfsc/jfsc1.jpg",NULL,NULL,NULL,NULL);
INSERT INTO product VALUES(NULL,"jfsc",NULL,"http://127.0.0.1:5000/home/jfsc/jfsc2.jpg",NULL,NULL,NULL,NULL);
INSERT INTO product VALUES(NULL,"jfsc",NULL,"http://127.0.0.1:5000/home/jfsc/jfsc3.jpg",NULL,NULL,NULL,NULL);
INSERT INTO product VALUES(NULL,"jfsc",NULL,"http://127.0.0.1:5000/home/jfsc/jfsc4.jpg",NULL,NULL,NULL,NULL);

#小白鞋
INSERT INTO product VALUES(NULL,"xbx","热风2018新品女士系带休闲鞋小白鞋H14W8501","http://127.0.0.1:5000/home/xbx/xbx1.jpg",98.00,129.00,"01黑色","34,35,39,37,38,39,40");
INSERT INTO product VALUES(NULL,"xbx","热风2018年春季新款女士时尚休闲鞋H14W8103","http://127.0.0.1:5000/home/xbx/xbx2.jpg",129.00,NULL,"01黑色","34,35,39,37,38,39,40");
INSERT INTO product VALUES(NULL,"xbx","热风2018年春季新款女士系带休闲鞋H14W8503","http://127.0.0.1:5000/home/xbx/xbx3.jpg",98.00,129.00,"01黑色","34,35,39,37,38,39,40");
INSERT INTO product VALUES(NULL,"xbx","热风2018年春季新款女士系带基本款硫化鞋H14W8105","http://127.0.0.1:5000/home/xbx/xbx4.jpg",149.00,NULL,"01黑色","34,35,39,37,38,39,40");

#平底鞋
INSERT INTO product VALUES(NULL,"pdx",NULL,"http://127.0.0.1:5000/home/pdx/pdx1.jpg",NULL,NULL,NULL,NULL);
INSERT INTO product VALUES(NULL,"pdx",NULL,"http://127.0.0.1:5000/home/pdx/pdx2.jpg",NULL,NULL,NULL,NULL);
INSERT INTO product VALUES(NULL,"pdx",NULL,"http://127.0.0.1:5000/home/pdx/pdx3.jpg",NULL,NULL,NULL,NULL);
INSERT INTO product VALUES(NULL,"pdx",NULL,"http://127.0.0.1:5000/home/pdx/pdx4.jpg",NULL,NULL,NULL,NULL);

#运动休闲鞋
INSERT INTO product VALUES(NULL,"ydxx","热风春季新款男士编织休闲鞋H46M8115","http://127.0.0.1:5000/home/ydxxx/ydxx1.jpg",149.00,NULL,"01黑色","34,35,39,37,38,39,40");
INSERT INTO product VALUES(NULL,"ydxx","热风2018年春季新款时尚女士休闲鞋H46W8504","http://127.0.0.1:5000/home/ydxxx/ydxx2.jpg",129.00,169.00,"01黑色","34,35,39,37,38,39,40");
INSERT INTO product VALUES(NULL,"ydxx","热风2018年春季新款编织女士休闲鞋H46W8102","http://127.0.0.1:5000/home/ydxxx/ydxx3.jpg",149.00,NULL,"01黑色","34,35,39,37,38,39,40");
INSERT INTO product VALUES(NULL,"ydxx","热风女士编织休闲鞋H46W8105","http://127.0.0.1:5000/home/ydxxx/ydxx4.jpg",149.00,NULL,"01黑色","34,35,39,37,38,39,40");
INSERT INTO product VALUES(NULL,"ydxx","热风2018奶牛春季新款女士编织套脚休闲鞋H46W8503","http://127.0.0.1:5000/home/ydxxx/ydxx4.jpg",109.00,169.00,"01黑色","34,35,39,37,38,39,40");

#滑板鞋
INSERT INTO product VALUES(NULL,"hbx","热风秋季新款女士系带休闲鞋H13W8323","http://127.0.0.1:5000/home/hbx/hbx1.jpg",349.00,NULL,"01黑色","34,35,39,37,38,39,40");

--首页轮播图
CREATE TABLE lun(
    id INT PRIMARY KEY AUTO_INCREMENT,
    isLun BOOLEAN,
    pic VARCHAR(248)
);
#轮播图
INSERT INTO lun VALUES(NULL,1,"http://127.0.0.1:5000/lun/lun1.png");
INSERT INTO lun VALUES(NULL,1,"http://127.0.0.1:5000/lun/lun2.png");
INSERT INTO lun VALUES(NULL,1,"http://127.0.0.1:5000/lun/lun3.png");
#头部导航
INSERT INTO lun VALUES(NULL,0,"http://127.0.0.1:5000/list1.jpg");
INSERT INTO lun VALUES(NULL,0,"http://127.0.0.1:5000/list2.jpg");
INSERT INTO lun VALUES(NULL,0,"http://127.0.0.1:5000/list3.jpg");
INSERT INTO lun VALUES(NULL,0,"http://127.0.0.1:5000/list4.jpg");

#bottom图片
INSERT INTO lun VALUES(NULL,2,"http://127.0.0.1:5000/home/bottom/bottom1.jpg");
INSERT INTO lun VALUES(NULL,2,"http://127.0.0.1:5000/home/bottom/bottom2.jpg");
INSERT INTO lun VALUES(NULL,2,"http://127.0.0.1:5000/home/bottom/bottom3.jpg");
INSERT INTO lun VALUES(NULL,2,"http://127.0.0.1:5000/home/bottom/bottom4.jpg");
INSERT INTO lun VALUES(NULL,2,"http://127.0.0.1:5000/home/bottom/bottom5.jpg");
INSERT INTO lun VALUES(NULL,2,"http://127.0.0.1:5000/home/bottom/bottom6.jpg");
INSERT INTO lun VALUES(NULL,2,"http://127.0.0.1:5000/home/bottom/bottom7.jpg");
INSERT INTO lun VALUES(NULL,2,"http://127.0.0.1:5000/home/bottom/bottom8.jpg");


--创建详情页轮播图imageList数据表
CREATE TABLE imageList(
    id INT PRIMARY KEY AUTO_INCREMENT,
    lunImage VARCHAR(1280),  #详情页轮播图
    cid INT        #相对product的图片
);


--创建shop购物车数据表
CREATE TABLE shop(
    sid INT PRIMARY KEY AUTO_INCREMENT,
    uname VARCHAR(18),  #购买用户用户名
    title VARCHAR(128), #标题
    pic VARCHAR(128),   #图片
    price DECIMAL(4,2), #价格
    color VARCHAR(128), #产品颜色
    size VARCHAR(128),  #产品尺寸
    counts INT   #数量
);


CREATE TABLE fenlei(
    sid INT PRIMARY KEY AUTO_INCREMENT,
    fid INT,
    fname VARCHAR(16), #类名
    fimg VARCHAR(128) #分类图片
);

INSERT INTO fenlei VALUES(NULL,10,'冬季女鞋','http://127.0.0.1:5000/fimg/dongjiqingcang.png');
INSERT INTO fenlei VALUES(NULL,20,'秋季女鞋','http://127.0.0.1:5000/fimg/qjnvxie.jpg');
INSERT INTO fenlei VALUES(NULL,30,'女士单鞋','http://127.0.0.1:5000/fimg/nvshidanxie.jpg');
INSERT INTO fenlei VALUES(NULL,40,'定制大&小码','http://127.0.0.1:5000/fimg/dingzhidaxiao.jpg');
INSERT INTO fenlei VALUES(NULL,50,'男鞋','http://127.0.0.1:5000/fimg/nanxie.jpg');
INSERT INTO fenlei VALUES(NULL,60,'童鞋','http://127.0.0.1:5000/fimg/tongxie.jpg');
INSERT INTO fenlei VALUES(NULL,70,'冬季清仓','http://127.0.0.1:5000/fimg/dongjiqingcang.png');
INSERT INTO fenlei VALUES(NULL,80,'女装','http://127.0.0.1:5000/fimg/nvzhuang.jpg');
INSERT INTO fenlei VALUES(NULL,90,'男装','http://127.0.0.1:5000/fimg/nanzhuang.jpg');
INSERT INTO fenlei VALUES(NULL,100,'行李箱','http://127.0.0.1:5000/fimg/xinglixiang.png');
INSERT INTO fenlei VALUES(NULL,110,'女包','http://127.0.0.1:5000/fimg/nvbao.jpg');
INSERT INTO fenlei VALUES(NULL,120,'男包','http://127.0.0.1:5000/fimg/nanbao.jpg');
INSERT INTO fenlei VALUES(NULL,130,'儿童背包','http://127.0.0.1:5000/fimg/ertonbao.png');
INSERT INTO fenlei VALUES(NULL,140,'女士配件','http://127.0.0.1:5000/fimg/nvshibeijian.jpg');
INSERT INTO fenlei VALUES(NULL,150,'男士配件','http://127.0.0.1:5000/fimg/nanshipeijian.jpg');



CREATE TABLE fenleiimg(
    sid INT PRIMARY KEY AUTO_INCREMENT,
    fid INT,
    pname VARCHAR(32),
    imgurl VARCHAR(128) 
);

INSERT INTO fenleiimg VALUES(NULL,10,'短靴','http://127.0.0.1:5000/images/duanxue.jpg');
INSERT INTO fenleiimg VALUES(NULL,10,'长靴','http://127.0.0.1:5000/images/changxue.jpg');
INSERT INTO fenleiimg VALUES(NULL,10,'切尔西靴','http://127.0.0.1:5000/images/qieerxi.jpg');
INSERT INTO fenleiimg VALUES(NULL,10,'时装靴','http://127.0.0.1:5000/images/shizhuang.jpg');
INSERT INTO fenleiimg VALUES(NULL,10,'家居拖','http://127.0.0.1:5000/images/jiaju.jpg');
INSERT INTO fenleiimg VALUES(NULL,10,'雪地靴','http://127.0.0.1:5000/images/xuedi.jpg');
INSERT INTO fenleiimg VALUES(NULL,10,'马丁靴','http://127.0.0.1:5000/images/mading.jpg');

INSERT INTO fenleiimg VALUES(NULL,20,'休闲鞋','http://127.0.0.1:5000/images/xiuxianxie.jpg');
INSERT INTO fenleiimg VALUES(NULL,20,'单鞋','http://127.0.0.1:5000/images/danxie.png');


INSERT INTO fenleiimg VALUES(NULL,30,'小白鞋','http://127.0.0.1:5000/images/xiaobaixie.jpg');
INSERT INTO fenleiimg VALUES(NULL,30,'休闲平底鞋','http://127.0.0.1:5000/images/xiuxianping.jpg');
INSERT INTO fenleiimg VALUES(NULL,30,'豆豆鞋','http://127.0.0.1:5000/images/doudouxie.jpg');
INSERT INTO fenleiimg VALUES(NULL,30,'滑板鞋','http://127.0.0.1:5000/images/huabanxie.jpg');
INSERT INTO fenleiimg VALUES(NULL,30,'时尚平底鞋','http://127.0.0.1:5000/images/shishangpi ng.jpg');
INSERT INTO fenleiimg VALUES(NULL,30,'粗跟鞋','http://127.0.0.1:5000/images/cugen.jpg');
INSERT INTO fenleiimg VALUES(NULL,30,'运行休闲鞋','http://127.0.0.1:5000/images/yundong xiu.jpg');
INSERT INTO fenleiimg VALUES(NULL,30,'细跟鞋','http://127.0.0.1:5000/images/xigen.jpg');
INSERT INTO fenleiimg VALUES(NULL,30,'低帮鞋','http://127.0.0.1:5000/images/dibang.jpg');

INSERT INTO fenleiimg VALUES(NULL,40,'短靴','http://127.0.0.1:5000/images/nvdaxiao.jpg');
INSERT INTO fenleiimg VALUES(NULL,40,'长靴','http://127.0.0.1:5000/images/nandaxiao.jpg');

INSERT INTO fenleiimg VALUES(NULL,50,'夹脚拖','http://127.0.0.1:5000/images/jiajiaotuo.jpg');
INSERT INTO fenleiimg VALUES(NULL,50,'软木拖','http://127.0.0.1:5000/images/ruanmu.jpg');
INSERT INTO fenleiimg VALUES(NULL,50,'凉鞋','http://127.0.0.1:5000/images/liangxie.jpg');
INSERT INTO fenleiimg VALUES(NULL,50,'拖鞋','http://127.0.0.1:5000/images/tuoxie.jpg');
INSERT INTO fenleiimg VALUES(NULL,50,'帆布鞋','http://127.0.0.1:5000/images/fanbu.jpg');
INSERT INTO fenleiimg VALUES(NULL,50,'布鞋','http://127.0.0.1:5000/images/buxie.jpg');
INSERT INTO fenleiimg VALUES(NULL,50,'运动鞋','http://127.0.0.1:5000/images/yundong.jpg');
INSERT INTO fenleiimg VALUES(NULL,50,'正装鞋','http://127.0.0.1:5000/images/zhengzhuang.jpg');
INSERT INTO fenleiimg VALUES(NULL,50,'休闲鞋','http://127.0.0.1:5000/images/nanxiuxian.jpg');
INSERT INTO fenleiimg VALUES(NULL,50,'懒人鞋','http://127.0.0.1:5000/images/lanren.jpg');
INSERT INTO fenleiimg VALUES(NULL,50,'靴子','http://127.0.0.1:5000/images/xuezi.jpg');
INSERT INTO fenleiimg VALUES(NULL,50,'高帮鞋','http://127.0.0.1:5000/images/nangaobang.jpg');
INSERT INTO fenleiimg VALUES(NULL,50,'家居拖','http://127.0.0.1:5000/images/nanjiaju.jpg');
INSERT INTO fenleiimg VALUES(NULL,50,'雪地鞋','http://127.0.0.1:5000/images/nanxuedi.jpg');

INSERT INTO fenleiimg VALUES(NULL,60,'凉鞋','http://127.0.0.1:5000/images/erliangxie.jpg');
INSERT INTO fenleiimg VALUES(NULL,60,'帆布鞋','http://127.0.0.1:5000/images/erfanbu.jpg');
INSERT INTO fenleiimg VALUES(NULL,60,'皮鞋','http://127.0.0.1:5000/images/erpixie.jpg');
INSERT INTO fenleiimg VALUES(NULL,60,'低帮鞋','http://127.0.0.1:5000/images/erdibang.jpg');
INSERT INTO fenleiimg VALUES(NULL,60,'布鞋','http://127.0.0.1:5000/images/erbuxie.jpg');
INSERT INTO fenleiimg VALUES(NULL,60,'雪地鞋','http://127.0.0.1:5000/images/erxuedi.jpg');

INSERT INTO fenleiimg VALUES(NULL,70,'马丁靴','http://127.0.0.1:5000/images/qingma.jpg');
INSERT INTO fenleiimg VALUES(NULL,70,'雪地靴','http://127.0.0.1:5000/images/qingxuedi.jpg');
INSERT INTO fenleiimg VALUES(NULL,70,'短靴','http://127.0.0.1:5000/images/qingduan.jpg');
INSERT INTO fenleiimg VALUES(NULL,70,'棉鞋','http://127.0.0.1:5000/images/qingmian.jpg');
INSERT INTO fenleiimg VALUES(NULL,70,'长靴','http://127.0.0.1:5000/images/qingchang.jpg');

INSERT INTO fenleiimg VALUES(NULL,80,'T恤','http://127.0.0.1:5000/images/txu.jpg');
INSERT INTO fenleiimg VALUES(NULL,80,'衬衫','http://127.0.0.1:5000/images/chenshan.jpg');
INSERT INTO fenleiimg VALUES(NULL,80,'外套','http://127.0.0.1:5000/images/waitao.jpg');
INSERT INTO fenleiimg VALUES(NULL,80,'连衣裙','http://127.0.0.1:5000/images/lianyi.jpg');
INSERT INTO fenleiimg VALUES(NULL,80,'半身裙','http://127.0.0.1:5000/images/banshen.jpg');
INSERT INTO fenleiimg VALUES(NULL,80,'卫衣','http://127.0.0.1:5000/images/weiyi.jpg');


INSERT INTO fenleiimg VALUES(NULL,90,'T恤','http://127.0.0.1:5000/images/nantxu.jpg');
INSERT INTO fenleiimg VALUES(NULL,90,'背心','http://127.0.0.1:5000/images/nanbeixin.jpg');
INSERT INTO fenleiimg VALUES(NULL,90,'衬衫/POLO衫','http://127.0.0.1:5000/images/poloshan.jpg');
INSERT INTO fenleiimg VALUES(NULL,90,'外套','http://127.0.0.1:5000/images/nanwaitao.jpg');
INSERT INTO fenleiimg VALUES(NULL,90,'卫衣','http://127.0.0.1:5000/images/nanweiyi.jpg');
INSERT INTO fenleiimg VALUES(NULL,90,'运动短裤','http://127.0.0.1:5000/images/yundongduan.jpg');
INSERT INTO fenleiimg VALUES(NULL,90,'牛仔裤','http://127.0.0.1:5000/images/nanniuzai.jpg');



INSERT INTO fenleiimg VALUES(NULL,100,'Diplomat皮箱','http://127.0.0.1:5000/images/Diplomat.jpg');

INSERT INTO fenleiimg VALUES(NULL,110,'斜挎包','http://127.0.0.1:5000/images/xiekua.jpg');
INSERT INTO fenleiimg VALUES(NULL,110,'帆布包','http://127.0.0.1:5000/images/fanbubao.jpg');
INSERT INTO fenleiimg VALUES(NULL,110,'钱包','http://127.0.0.1:5000/images/qianbao.jpg');
INSERT INTO fenleiimg VALUES(NULL,110,'卡包','http://127.0.0.1:5000/images/kabao.jpg');
INSERT INTO fenleiimg VALUES(NULL,110,'手提包','http://127.0.0.1:5000/images/shouti.jpg');


INSERT INTO fenleiimg VALUES(NULL,120,'钱包','http://127.0.0.1:5000/images/nanqianbao.jpg');
INSERT INTO fenleiimg VALUES(NULL,120,'卡包','http://127.0.0.1:5000/images/nankabao.jpg');
INSERT INTO fenleiimg VALUES(NULL,120,'钥匙包','http://127.0.0.1:5000/images/yaoshibao.jpg');
INSERT INTO fenleiimg VALUES(NULL,120,'手拿包','http://127.0.0.1:5000/images/shounabao.jpg');
INSERT INTO fenleiimg VALUES(NULL,120,'单肩包','http://127.0.0.1:5000/images/danjian.jpg');
INSERT INTO fenleiimg VALUES(NULL,120,'双肩包','http://127.0.0.1:5000/images/shuangjian.jpg');

INSERT INTO fenleiimg VALUES(NULL,130,'儿童背包','http://127.0.0.1:5000/images/erbeibao.jpg');

INSERT INTO fenleiimg VALUES(NULL,140,'帽子','http://127.0.0.1:5000/images/nvmao.jpg');
INSERT INTO fenleiimg VALUES(NULL,140,'丝巾','http://127.0.0.1:5000/images/sijin.jpg');
INSERT INTO fenleiimg VALUES(NULL,140,'眼镜','http://127.0.0.1:5000/images/nvyanjing.jpg');
INSERT INTO fenleiimg VALUES(NULL,140,'皮带','http://127.0.0.1:5000/images/nvpidai.jpg');
INSERT INTO fenleiimg VALUES(NULL,140,'袜子','http://127.0.0.1:5000/images/nvwazi.jpg');


INSERT INTO fenleiimg VALUES(NULL,150,'眼镜','http://127.0.0.1:5000/images/nanyanjing.jpg');
INSERT INTO fenleiimg VALUES(NULL,150,'皮带','http://127.0.0.1:5000/images/nanpidai.jpg');
INSERT INTO fenleiimg VALUES(NULL,150,'袜子','http://127.0.0.1:5000/images/nanwazi.jpg');
INSERT INTO fenleiimg VALUES(NULL,150,'鞋垫','http://127.0.0.1:5000/images/xiedian.jpg');
INSERT INTO fenleiimg VALUES(NULL,150,'围巾','http://127.0.0.1:5000/images/weijin.jpg');


CREATE TABLE detailImg(
    id INT PRIMARY KEY AUTO_INCREMENT,
    dType INT,
    imgurl VARCHAR(128)  
);

INSERT INTO detailImg VALUES(NULL,10,'http://127.0.0.1:5000/images/jw1.jpg');
INSERT INTO detailImg VALUES(NULL,10,'http://127.0.0.1:5000/images/jw2.jpg');
INSERT INTO detailImg VALUES(NULL,10,'http://127.0.0.1:5000/images/jw3.jpg');
INSERT INTO detailImg VALUES(NULL,10,'http://127.0.0.1:5000/images/jw4.jpg');
INSERT INTO detailImg VALUES(NULL,20,'http://127.0.0.1:5000/images/xj2.jpg');
INSERT INTO detailImg VALUES(NULL,20,'http://127.0.0.1:5000/images/xj3.jpg');
INSERT INTO detailImg VALUES(NULL,20,'http://127.0.0.1:5000/images/xj4.jpg');
INSERT INTO detailImg VALUES(NULL,20,'http://127.0.0.1:5000/images/xj5.jpg');
INSERT INTO detailImg VALUES(NULL,20,'http://127.0.0.1:5000/images/xj6.jpg');
INSERT INTO detailImg VALUES(NULL,20,'http://127.0.0.1:5000/images/mt1.jpg');
INSERT INTO detailImg VALUES(NULL,20,'http://127.0.0.1:5000/images/mt2.jpg');
INSERT INTO detailImg VALUES(NULL,20,'http://127.0.0.1:5000/images/mt3.jpg');
INSERT INTO detailImg VALUES(NULL,20,'http://127.0.0.1:5000/images/mt4.jpg');
INSERT INTO detailImg VALUES(NULL,20,'http://127.0.0.1:5000/images/mt5.jpg');
INSERT INTO detailImg VALUES(NULL,30,'http://127.0.0.1:5000/images/sc.jpg');
INSERT INTO detailImg VALUES(NULL,30,'http://127.0.0.1:5000/images/cl.jpg');
INSERT INTO detailImg VALUES(NULL,30,'http://127.0.0.1:5000/images/info.jpg');
INSERT INTO detailImg VALUES(NULL,40,'http://127.0.0.1:5000/images/xhzs.jpg');






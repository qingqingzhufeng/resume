const express = require("express");
const pool = require("../pool");

var router = express.Router();

router.get('/lun',(req,res)=>{
    var sql = "SELECT * FROM lun";
    pool.query(sql,[],(err,result)=>{
        if(err) throw err;
        res.send({code:200,msg:result});
    })
});
module.exports = router;

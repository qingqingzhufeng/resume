const express = require("express");
const pool = require("../pool");

var router = express.Router();
router.post('/search',(req,res)=>{
    var { value } = req.body;
    console.log(value);
    var s = value.split("");
    var t = "%"+s.join("%")+"%";
    var sql = `SELECT * FROM product WHERE title LIKE ? `;
    pool.query(sql,[t],(err,result)=>{
        if(err) throw err;
        res.send({code:200,msg:result});
    });
});
module.exports = router;
const express = require("express");
const pool = require("../pool");

var router = express.Router();
router.get('/product',(req,res)=>{
    var { id } = req.query;
    var sql = "SELECT * FROM product WHERE id = ?";
    pool.query(sql,[id],(err,result)=>{
        if(err) throw err;
        res.send({code:200,msg:result});
    });
});

router.get('/all',(req,res)=>{
    var sql = "SELECT * FROM product ";
    var list = {
        recommended:[],//本周尖货推荐
        hddh:[],  //活动导航
        nvx:[],   //靓丽女鞋
        llnx:[],  //舒适男鞋
        nanx:[],
        ssnx:[],
        jpnb:[],
        ssnb:[],
        nvfszq:[],
        nvb:[],   //时尚女包
        nanb:[],  //精品男包
        nannv:[], //男女服饰专区
        jfsc:[],  //积分商城
        xbx:[],   //小白鞋
        pdx:[],   //平底鞋
        ydxx:[],  //运动休闲鞋
        hbx:[]    //滑板鞋
    };
    pool.query(sql,[],(err,result)=>{
        if(err) throw err;
        for(var tmp of result){
            switch(tmp.head){
                case 'recommended':
                    list.recommended.push(tmp);
                    break;
                case 'hddh':
                    list.hddh.push(tmp);
                    break;
                case 'nvx':
                    list.nvx.push(tmp);
                    break;
                case 'llnx':
                    list.llnx.push(tmp);
                    break;
                case 'nanx':
                    list.nanx.push(tmp);
                    break;
                case 'ssnx':
                    list.ssnx.push(tmp);
                    break;
                case 'ssnb':
                    list.ssnb.push(tmp);
                    break;
                case 'jpnb':
                    list.jpnb.push(tmp);
                    break;
                case 'nvb':
                    list.nvb.push(tmp);
                    break;
                case 'nanb':
                    list.nanb.push(tmp);
                    break;
                case 'nannv':
                    list.nannv.push(tmp);
                    break;
                case 'jfsc':
                    list.jfsc.push(tmp);
                    break;
                case 'xbx':
                    list.xbx.push(tmp);
                    break;
                case 'pdx':
                    list.pdx.push(tmp);
                    break;
                case 'ydxx':
                    list.ydxx.push(tmp);
                    break;
                case 'hbx':
                    list.hbx.push(tmp);
                    break;
                case 'nvfszq':
                    list.nvfszq.push(tmp);
                    break;
            }
        }
        res.send({code:200,msg:list});
    });
})

router.get('/fenlei',(req,res)=>{
    var sql = "SELECT * FROM fenlei";
    pool.query(sql,[],(err,result)=>{
        if(err) throw err;
        res.send({code:200,msg:result});
    })
});

router.get('/fenleiimg',(req,res)=>{
    var fid=req.query.fid;
    var sql = "SELECT * FROM fenleiimg WHERE fid=?";
    pool.query(sql,[fid],(err,result)=>{
        if(err) throw err;
        res.send({code:200,msg:result});
    });
})
router.get('/proImg',(req,res)=>{
    var sql = "SELECT * FROM detailImg";
    pool.query(sql,[],(err,result)=>{
        if(err) throw err;
        res.send({code:200,msg:result});
    });
});
router.post('/addOrder',(req,res)=>{
    var {pid,userID,nums,color,size} = req.body.order;
    var sql = `INSERT INTO order VALUES(NULL,?,?,?,?,?)`;
    pool.query(sql, [pid, nums, color, size,userID],(err,result)=>{
        if(err) throw err;
        res.send({code:200,msg:"提交订单成功"});
    })
});
//导出路由
module.exports = router;
const express = require("express");
var request = require('request');

var router = express.Router();

router.get('/getCode',(req,res)=>{
    var code = req.query.code;
    var url = `https://api.weixin.qq.com/sns/jscode2session?appid=wx11b76fea5b9a449b&secret=6a85196b08c39774d5c35f2b62fca258&js_code=${code}&grant_type=authorization_code`;
    request(url, function (err, response,body){
        if(!err){
            res.send(body);
        }
    });
    
});

module.exports = router;